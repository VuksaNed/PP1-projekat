// generated with ast extension for cup
// version 0.8
// 26/0/2022 15:17:51


package rs.ac.bg.etf.pp1.ast;

public class ConstDeclarComma extends ConstDeclComma {

    private ConstAsign ConstAsign;

    public ConstDeclarComma (ConstAsign ConstAsign) {
        this.ConstAsign=ConstAsign;
        if(ConstAsign!=null) ConstAsign.setParent(this);
    }

    public ConstAsign getConstAsign() {
        return ConstAsign;
    }

    public void setConstAsign(ConstAsign ConstAsign) {
        this.ConstAsign=ConstAsign;
    }

    public void accept(Visitor visitor) {
        visitor.visit(this);
    }

    public void childrenAccept(Visitor visitor) {
        if(ConstAsign!=null) ConstAsign.accept(visitor);
    }

    public void traverseTopDown(Visitor visitor) {
        accept(visitor);
        if(ConstAsign!=null) ConstAsign.traverseTopDown(visitor);
    }

    public void traverseBottomUp(Visitor visitor) {
        if(ConstAsign!=null) ConstAsign.traverseBottomUp(visitor);
        accept(visitor);
    }

    public String toString(String tab) {
        StringBuffer buffer=new StringBuffer();
        buffer.append(tab);
        buffer.append("ConstDeclarComma(\n");

        if(ConstAsign!=null)
            buffer.append(ConstAsign.toString("  "+tab));
        else
            buffer.append(tab+"  null");
        buffer.append("\n");

        buffer.append(tab);
        buffer.append(") [ConstDeclarComma]");
        return buffer.toString();
    }
}
